"use client";

import { useState } from "react";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { PageContainer } from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";

function ScanContent() {
  const [uid, setUid] = useState("");
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleLookup() {
    if (!uid.trim()) return;
    setLoading(true);
    setError(null);
    setSummary(null);
    try {
      const res = await fetch("/api/customer-summary", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ uid: uid.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Lookup failed");
      setSummary(data.summary);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageContainer size="md" className="flex flex-1 flex-col gap-6 py-8">
      <div>
        <h1 className="text-2xl font-medium text-trackbite-gray-900">Scan a customer</h1>
        <p className="mt-1 text-sm text-trackbite-gray-500">
          Enter the customer&apos;s Food ID (their account UID) to pull up their AI summary.
          Once QR scanning is wired in, this field will fill in automatically.
        </p>
      </div>

      <Card padding="lg" className="flex flex-col gap-4">
        <Input
          label="Customer Food ID"
          placeholder="e.g. aB3xQ..."
          value={uid}
          onChange={(e) => setUid(e.target.value)}
        />
        <Button onClick={handleLookup} disabled={loading || !uid.trim()} fullWidth>
          {loading ? "Looking up..." : "Get summary"}
        </Button>
      </Card>

      {error && (
        <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>
      )}

      {summary && (
        <Card padding="lg">
          <p className="text-xs font-semibold uppercase tracking-wide text-trackbite-green">
            Trackbite AI summary
          </p>
          <p className="mt-2 text-sm leading-relaxed text-trackbite-gray-800">{summary}</p>
        </Card>
      )}
    </PageContainer>
  );
}

export default function RestaurantScanPage() {
  return (
    <ProtectedRoute requiredRole="restaurant">
      <ScanContent />
    </ProtectedRoute>
  );
}